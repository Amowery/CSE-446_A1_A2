﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int upper = 100, lower = 0; 
            ServiceReference1.Service1Client myClient = new ServiceReference1.Service1Client("BasicHttpBinding_IService1");
            int sNum = myClient.SecretNumber(lower, upper);
            Console.WriteLine("The secret number is: {0}", sNum);

            Console.WriteLine("Enter a guess: ");
            int userNum = Convert.ToInt32(Console.ReadLine());
            string checkNum = myClient.checkNumber(userNum, sNum);

            Console.WriteLine(checkNum);
            Console.ReadLine(); 
        }
    }
}
