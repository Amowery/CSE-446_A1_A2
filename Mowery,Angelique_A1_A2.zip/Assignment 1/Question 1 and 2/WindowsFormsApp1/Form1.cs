﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        int sNum;
        int count;
        ServiceReference1.Service1Client myClient = new ServiceReference1.Service1Client("BasicHttpBinding_IService1");
        public Form1()
        {
            InitializeComponent();
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int lower = Convert.ToInt32(textBox1.Text);
            int upper = Convert.ToInt32(textBox2.Text); 
            sNum = myClient.SecretNumber(lower, upper);
                 
        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {
            //number of attempts made
        }

        private void label6_Click(object sender, EventArgs e)
        {
            //your guess is
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int userNum = Convert.ToInt32(textBox3.Text);
            string checkNum = myClient.checkNumber(userNum, sNum);

            
            count++; 
            label5.Text = "Number of attempts made: " + count.ToString();

            label6.Text = "Your guess is: " + checkNum; 
        }
    }
}
