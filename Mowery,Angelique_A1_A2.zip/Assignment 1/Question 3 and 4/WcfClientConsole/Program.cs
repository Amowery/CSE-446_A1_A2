﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel; 

namespace WcfClientConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            NumberGuessInterfaceClient myProxy = new NumberGuessInterfaceClient();
            Console.WriteLine("Welcome to Number Guessing Game");
            Console.WriteLine("Enter lower bound: ");
            int lower = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Upper bound: ");
            int upper = Convert.ToInt32(Console.ReadLine()); 
            int sNum = myProxy.SecretNumber(lower, upper);

            Console.WriteLine("Enter your guess: ");
            int userNum = Convert.ToInt32(Console.ReadLine());
            string numCheck = myProxy.checkNumber(userNum, sNum);
            Console.WriteLine(numCheck);
            Console.WriteLine("The number was: " + sNum);
            myProxy.Close();
            Console.WriteLine("/nPress <Enter> to terminate the client. /n");
            Console.ReadLine();

        }
    }
}
