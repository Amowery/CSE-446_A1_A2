﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MyMvcCoreApp.Models;

namespace MyMvcCoreApp.Controllers
{
    public class HomeController : Controller
    {
        string BaseUrl = "http://localhost:50650/Service1.svc";
        public IActionResult Index()
        {
     
            return View();
        }
        [HttpGet]
        public ViewResult SecretNumber()
        {
            return View(); 
        }
        [HttpPost]
        public ViewResult SecretNumber(int lower, int upper)
        {
            
            return View("25"); 
        }
        [HttpGet]
        public ViewResult checkNumber()
        {
            return View(); 
        }
        [HttpPost]
        public ViewResult checkNumber(int userNum, int sNum)
        {
            return View("Too Low"); 
        }
       /* public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }*/
       /* public IActionResult About()
        {
            ViewData["Message"] = "Welcome to Number Guessing Game";
            return View(); 
        }*/

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new SecretNumber{ RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
