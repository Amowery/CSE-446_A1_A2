using System;

namespace MyMvcCoreApp.Models
{
    public class SecretNumber
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
        public int lower { get; set; }
        public int Upper { get; set; }
        public int sNum { get; set; }
        public int Guess { get; set;  }


    }
}