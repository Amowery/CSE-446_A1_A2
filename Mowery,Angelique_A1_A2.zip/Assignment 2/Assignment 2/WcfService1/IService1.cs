﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;


namespace WcfService1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        [WebGet]
        string GetData(int value);

        [OperationContract]
        [WebGet(UriTemplate = "sNum?lower={lower}&upper={upper}", ResponseFormat = WebMessageFormat.Json)]
        int SecretNumber(int lower, int upper);

        [OperationContract]
        [WebGet(UriTemplate = "cNum?userNum={userNum}&SecretNum={SecretNum}", ResponseFormat = WebMessageFormat.Json)]
        string checkNumber(int userNum, int SecretNum);
        // TODO: Add your service operations here
    }
}
